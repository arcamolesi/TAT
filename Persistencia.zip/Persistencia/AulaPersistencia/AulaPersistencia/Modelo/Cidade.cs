﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema; 

namespace AulaPersistencia.Modelo
{
    [Table("Cidades")]
    public class Cidade
    {
        public Cidade()
        {
            this.clientes = new HashSet<Cliente>();
        }

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int id { get; set; }

        [StringLength(35)]
        public string nome { get; set; }

        [StringLength(2)]
        public string uf { get; set; }

        public int qtde { get; set; }

        public virtual ICollection<Cliente> clientes { get; set; }
    }
}
