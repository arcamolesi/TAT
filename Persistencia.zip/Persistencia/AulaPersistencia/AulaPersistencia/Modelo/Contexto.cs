﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity; 

namespace AulaPersistencia.Modelo
{
    public class Contexto: DbContext
    {
       public Contexto() : base("TAT2020") { }

       public DbSet<Cidade> Cidades { get; set; }
       public DbSet<Cliente> Clientes { get; set; }
    }
}
