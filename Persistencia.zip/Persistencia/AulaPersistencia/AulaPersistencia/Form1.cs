﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AulaPersistencia.Modelo;

namespace AulaPersistencia
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Cidade cidade = new Cidade();
            cidade.id = Convert.ToInt32(txtId.Text);
            cidade.nome = txtNome.Text;
            cidade.uf = txtUf.Text;
            cidade.qtde = Convert.ToInt32(txtQtde.Text);

            Contexto contexto = new Contexto();
            contexto.Cidades.Add(cidade);
            contexto.SaveChanges();

            dataGridView1.DataSource = contexto.Cidades.ToList(); 
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Contexto contexto = new Contexto();

            Cidade cidade = contexto.Cidades.Find(Convert.ToInt32(txtId.Text));

            cidade.id = Convert.ToInt32(txtId.Text);
            cidade.nome = txtNome.Text;
            cidade.uf = txtUf.Text;
            cidade.qtde = Convert.ToInt32(txtQtde.Text);

            contexto.Entry(cidade).State = EntityState.Modified;
            contexto.SaveChanges();

            dataGridView1.DataSource = contexto.Cidades.ToList(); 

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Contexto contexto = new Contexto();
            Cidade cidade = contexto.Cidades.Find(Convert.ToInt32(txtId.Text));


            contexto.Cidades.Remove(cidade); 
            contexto.SaveChanges();

            dataGridView1.DataSource = contexto.Cidades.ToList();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Contexto contexto = new Contexto();
            Cidade cidade = contexto.Cidades.Find(Convert.ToInt32(txtId.Text));

            List<Cliente> clientes = cidade.clientes.ToList();
            dataGridView2.DataSource = clientes; 
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Contexto contexto = new Contexto();
            dataGridView1.DataSource = contexto.Cidades.ToList(); 
        }
    }
}
